/*
 * Interfacing_Modules_AMIT_F20.c
 *
 * Created: 8/7/2021 7:52:48 PM
 * Author : 20100
 */ 


//#include "LCD.h"
//#include "ADC.h"
//#include "KEYPAD.h"
#include "Timer0.h"
#include "DIO.h"
#include "SPI.h"
#include "OUTPUT_Module.h"
// Micro controller Configuration:((this should be moved to a standalone MC configuration header file)).
//--------------------------------
////////////////////////////////////////////////////////////////////////////////////////////////





int main(void)
{
	//LED0_Initialize();
	//LED1_Initialize();
	//LED1_ON();
	//LED2_Initialize();
	
	//Timer0_Normal_OVF_Without_Interrupt_Initialization();
	//Timer0_Normal_OVF_Without_Interrupt_Start();
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN0, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN1, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN2, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN3, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN4, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN5, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN6, DIO_OUTPUT);
	DIO_SetPin_Direction(DIO_PORTD, DIO_PIN7, DIO_OUTPUT);
	SPI_Init();
	//uint8_t MS_data = 0XFF;
    while (1) //super loop
    {
		PORTD = SPI_Receive();
    }
}

