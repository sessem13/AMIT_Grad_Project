/*
 * UART_Configuration.h
 *
 * Created: 9/3/2021 9:32:38 PM
 *  Author: 20100
 */ 


#ifndef UART_CONFIGURATION_H_
#define UART_CONFIGURATION_H_

//renaming registers:

//renaming pins:

//renaming states:

//


#endif /* UART_CONFIGURATION_H_ */