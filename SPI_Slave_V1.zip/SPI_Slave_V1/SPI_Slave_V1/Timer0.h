/*
 * Timer0.h
 *
 * Created: 8/27/2021 9:21:22 PM
 *  Author: karim
 */ 


#ifndef TIMER0_H_
#define TIMER0_H_

#include "Timer0_Config.h"
/*
There are two paths to work on Timer0:
Timer0 without Interrupt & Timer0 with Interrupt.
We will create functions for Timer0 in both paths and in the modes "Normal", "CTC", and "Fast PWM".
*/
//Timer0 in normal mode without over flow interrupt:
void Timer0_Normal_OVF_Without_Interrupt_Initialization(void);		//initializtion for registers and conditions/flags.
void Timer0_Normal_OVF_Without_Interrupt_Start(void);				//Timer0 start counting
void Timer0_Normal_OVF_Without_Interrupt_Stop(void);				//Force Timer0 stop counting
void Timer0_Normal_OVF_Without_Interrupt_Delay(uint32_t delay);		//Delay function using timer0

//Timer0 in normal mode with over flow interrupt:
void Timer0_Normal_OVF_With_Interrupt_Initialization(void);
void Timer0_Normal_OVF_With_Interrupt_Start(void);
void Timer0_Normal_OVF_With_Interrupt_Stop(void);
void Timer0_Normal_OVF_With_Interrupt_Delay(uint32_t delay);

//Timer0 in CTC mode without interrupt:
void Timer0_ClearCompare_CTC_Without_Interrupt_Initialization(void);
void Timer0_ClearCompare_CTC_Without_Interrupt_Start(void);
void Timer0_ClearCompare_CTC_Without_Interrupt_Stop(void);
void Timer0_ClearCompare_CTC_Without_Interrupt_Delay(uint32_t delay, uint8_t ocr);

//Timer0 in CTC mode with interrupt:
void Timer0_ClearCompare_CTC_With_Interrupt_Initialization(void);
void Timer0_ClearCompare_CTC_With_Interrupt_Start(void);
void Timer0_ClearCompare_CTC_With_Interrupt_Stop(void);
void Timer0_ClearCompare_CTC_With_Interrupt_Delay(uint32_t delay, uint8_t ocr);

//Timer0 in Fast PWM mode:
void Timer0_Fast_PWM_Initialization(void);
void Timer0_Fast_PWM_NonInverting_SetDutyCycle(uint8_t duty);
void Timer0_Fast_PWM_Inverting_SetDutyCycle(uint8_t duty);

#endif /* TIMER0_H_ */