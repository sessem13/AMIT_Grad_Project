/*
 * Interfacing_Modules_AMIT_F20.c
 *
 * Created: 8/7/2021 7:52:48 PM
 * Author : 20100
 */ 


//#include "LCD.h"
//#include "ADC.h"
//#include "KEYPAD.h"
#include "Timer0.h"
#include "DIO.h"
#include "SPI.h"
#include "OUTPUT_Module.h"
#include "UART.h"

int main(void)
{
	
	UART_Init();
	SPI_Init();
	SPI_SlaveSelect(0);
	//uint8_t MS_data = 0X33;
	uint8_t BL_data;
    while (1) //super loop
    {
		UART_Transmit('A');
		BL_data = UART_Receive();
		if(BL_data == '1')
		{
			SPI_Transmit(0XFF);
			LED0_ON();
			LED1_ON();
		}
		else
		{
			SPI_Transmit(0X00);
			LED0_OFF();
			LED1_OFF();
		}
		//SPI_Transmit(BL_data);
    }
}

