/*
* SPI.c
*
* Created: 2/19/2021 8:18:56 PM
*  Author: karim
*/


#include "SPI.h"

void SPI_Init(void)
{
	#if SPI_MODE == MASTER
	SET_BIT(SPI_PORT, MOSI);	/*Define direction as output*/
	CLR_BIT(SPI_PORT, MISO);	/*Define direction as input*/
	SET_BIT(SPI_PORT, CLK);		/*Define direction as output*/
	SET_BIT(SPI_PORT, SS);		/*Define direction as output*/
	/*
	SPCR: SPI Control Register:
	| Bit7 | Bit6 | Bit5 | Bit4 | Bit3 | Bit2 | Bit1 | Bit0 |
	| SPIE | SPE  | DORD | MSTR | CPOL | CPHA | SPR1 | SPR0 |
	SPIE: SPI Interrupt Enable Bit -->> SPIE = 0 [Disable Interrupt].
	SPE : SPI Enable Bit		   -->> SPE  = 1 [Enable the SPI].
	DORD: SPI Data order		   -->> DORD = 0 [MSB of data is transmitted first].
	MSTR: SPI Master/Slave select bit > MSTR = 1 [Master, check the SPI_Mode == MASTER above].
	CPOL: Clock Polarity bit	   -->> CPOL = 0 [rising edge].
	CPHA: Clock Phase bit          -->> CPHA = 0 [].
	SPR1, SPR0: clock rate select bits> SPR1:SPR0 = 11 [Fosc/128].
	*/
	SPCR = 0x53;				//0b 0101 0011
	
	#elif SPI_MODE == SLAVE
	CLR_BIT(SPI_PORT, MOSI);/*Define direction as input*/
	SET_BIT(SPI_PORT, MISO);/*Define direction as output*/
	CLR_BIT(SPI_PORT, CLK);/*Define direction as input*/
	CLR_BIT(SPI_PORT, SS); /*Define direction as input*/
	//the only difference here in configuring SPCR is the MSTR will be cleared to 0.
	SPCR = 0x43;//0b 0100 0011
	#endif
}
void SPI_Transmit(uint8_t data) 
{
	SPDR = data; //put data you want to send in the data register
	while (GET_BIT(SPSR, SPIF) != 1); 
	// data will be sent if the SPI interrupt Flag is not set in the SPI Status Register, if it is raised transmission will stop
}
uint8_t SPI_Receive(void)
{
	// data will be sent if the SPI interrupt Flag is not set in the SPI Status Register, if it is raised transmission will stop
	while (GET_BIT(SPSR, SPIF) != 1);
	return SPDR;
}
void SPI_SlaveSelect(uint8_t slave)
{
	switch (slave)
	{
		case 0:
		CLR_BIT(PORTB, SS);
		break;
		case 1:
		break;
	}
}

SPI_Status SPI_Transeive(uint8_t dataSent, uint8_t* dataReceived) // ?? ???? ?? ???
{
	SPDR = dataSent;//To Slave
	while (GET_BIT(SPSR, SPIF) != 1);
	*dataReceived = SPDR;//From Slave
	return SPI_OK;
}

