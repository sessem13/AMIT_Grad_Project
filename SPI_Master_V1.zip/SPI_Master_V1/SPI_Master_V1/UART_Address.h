/*
 * UART_Address.h
 *
 * Created: 9/3/2021 9:32:05 PM
 *  Author: 20100
 */ 


#ifndef UART_ADDRESS_H_
#define UART_ADDRESS_H_


//---------------------------------------//
#define UDR		(*(volatile uint8_t*)(0x2C))		//USART I/O Data Register
#define UCSRA	(*(volatile uint8_t*)(0x2B))		//USART control and status register A
#define UCSRB	(*(volatile uint8_t*)(0x2A))		//USART control and status register B
#define UCSRC	(*(volatile uint8_t*)(0x40))		//USART register select and mode select 
#define UBRRH	(*(volatile uint8_t*)(0x40))		//USART control and status register B
#define UBRRL	(*(volatile uint8_t*)(0x29))		//USART control and status register B


#endif /* UART_ADDRESS_H_ */