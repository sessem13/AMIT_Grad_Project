/*
 * S7SEG_Configuration.h
 *
 * Created: 8/13/2021 8:39:49 PM
 *  Author: 20100
 */ 


#ifndef S7SEG_CONFIGURATION_H_
#define S7SEG_CONFIGURATION_H_

#include "CPU_Configuration.h"


//renaming portb as control port and porta as data port:
#define S7SEG_CNTRL_PORT DIO_PORTB
#define S7SEG_DATA_PORT  DIO_PORTA

// renaming Enable pins and Dot
#define S7SEG_EN1		 DIO_PIN1
#define S7SEG_EN2		 DIO_PIN2
#define S7SEG_DIP		 DIO_PIN3

// renaming data pins:
#define S7SEG_DTA_A		 DIO_PIN4
#define S7SEG_DTA_B		 DIO_PIN5
#define S7SEG_DTA_C		 DIO_PIN6
#define S7SEG_DTA_D		 DIO_PIN7

// renaming states:

#define S7SEG_OUTPUT	 DIO_OUTPUT

#define S7SEG_LOW		 DIO_LOW
#define S7SEG_HIGH		 DIO_HIGH

#endif /* S7SEG_CONFIGURATION_H_ */