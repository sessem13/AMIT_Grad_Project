/*
 * Timer0_Address.h
 *
 * Created: 8/27/2021 9:21:00 PM
 *  Author: karim
 */ 


#ifndef TIMER0_ADDRESS_H_
#define TIMER0_ADDRESS_H_


/*Register address form register summary*/
/*
#define TCNT0 (*(volatile Uint8t*)(0x52)) //Timer Counter Register 0
#define TCCR0 (*(volatile Uint8t*)(0x53)) //Timer Counter Control Register 0
#define TIFR  (*(volatile Uint8t*)(0x58)) //Timer Counter Interrupt Flag Register
#define TIMSK (*(volatile Uint8t*)(0x59)) //Timer Interrupt Mask Register
#define OCR0  (*(volatile Uint8t*)(0x5C)) //
*/


#endif /* TIMER0_ADDRESS_H_ */